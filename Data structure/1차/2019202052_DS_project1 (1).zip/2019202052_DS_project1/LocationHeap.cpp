/*
#include "LocationHeap.h"

LocationHeap::LocationHeap()
{

}

LocationHeap::~LocationHeap()
{

}

bool LocationHeap::Insert(char * location)
{
    //BPOP
}

void LocationHeap::Print()
{
    //PRINT H
}
*/