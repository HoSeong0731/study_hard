/*
#include "LocationHeapNode.h"

LocationHeapNode::LocationHeapNode()
{

}

LocationHeapNode::~LocationHeapNode()
{

}

int LocationHeapNode::GetCount()
{

}

char * LocationHeapNode::GetLoc()
{

}

void LocationHeapNode::SetCount(int count)
{

}

void LocationHeapNode::SetLoc(char * location)
{

}
*/