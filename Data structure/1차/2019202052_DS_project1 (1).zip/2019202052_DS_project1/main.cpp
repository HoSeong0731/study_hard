#include "Manager.h"

int main()
{
	Manager manager;
	manager.run("command.txt");	//run command
	return 0;
}
