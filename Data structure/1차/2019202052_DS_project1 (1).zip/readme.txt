visualstudio에서 작업하다가 linux로 옮기는 걸 실패해 tar.az형식이 아닙니다..
양해부탁드립니다.. (감점받도록 하겠습니다.)

현재 코드가 qpop에서 오류가 나는 상태라 print, search또한 안됩니다.
queue, Location_BST에서 삽입, Patient_BST에서 삽입까지 정상적으로 작동하는 것을 확인했습니다.
